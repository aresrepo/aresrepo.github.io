# -*- coding: utf-8 -*-
import zlib, base64

_C = r'''# -*- coding: utf-8 -*-
import sys
import os
import urllib.parse
import urllib.request
import ssl
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import base64
import re
import html
import datetime

# ==================== CONFIGURAÇÕES GERAIS ====================
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0]
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

# IMAGENS PRINCIPAIS
IMG_TV     = "https://archive.org/download/hadesfilmes/hadestv2.png"
IMG_FILMES = "https://archive.org/download/hadesfilmes/hadesfilmes.png"
IMG_SERIES = "https://archive.org/download/hadesfilmes/hadesseries.png"
IMG_CONTA  = "https://archive.org/download/hadesinformacaodaconta/hadesinformacaodaconta.png"

# IMAGENS ESPECÍFICAS DE BUSCA
IMG_SEARCH_TV     = "https://archive.org/download/hadesbuscatv/hadesbuscatv.png"
IMG_SEARCH_FILMES = "https://archive.org/download/hadesbuscatv/haresbuscafilmesvod.png"
IMG_SEARCH_SERIES = "https://archive.org/download/hadesbuscatv/hadesbuscaseries.png"

AUTH_SITE = "https://addoncavaleirorepo2.alwaysdata.net/"
# --- NOVA URL PRINCIPAL ---
REMOTE_LISTS_URL = "https://drive.google.com/uc?export=download&id=1OEvQu8ta9wTNa_WCGyXTvA-AcMVxULSA" # URL CORRIGIDA COM O SEU NOVO ID

ADULT_PIN = "6699"
ADULT_KEYS =['adult', 'xxx', 'porn', '+18', '🔞', 'sexo', 'hentai', 'sextv', 'prive', 'sexy']

def apply_fanart(li, fanart_url):
    li.setArt({'fanart': fanart_url, 'thumb': fanart_url, 'icon': fanart_url, 'poster': fanart_url})
    li.setProperty('fanart_image', fanart_url)

def hades_auto_optimize():
    try:
        translate = xbmcvfs.translatePath if hasattr(xbmcvfs, 'translatePath') else xbmc.translatePath
        profile_path = translate('special://userdata/')
        adv_file = os.path.join(profile_path, 'advancedsettings.xml')
        optimized_xml = """<advancedsettings><cache><buffermode>1</buffermode><memorysize>157286400</memorysize><readfactor>30</readfactor></cache><network><curlclienttimeout clerk="45"></curlclienttimeout><curllowspeedtime>45</curllowspeedtime></network></advancedsettings>"""
        if not os.path.exists(adv_file):
            with open(adv_file, 'w', encoding='utf-8') as f: f.write(optimized_xml)
    except: pass

class NetUtils:
    def __init__(self):
        self.ctx = ssl.create_default_context()
        self.ctx.check_hostname = False
        self.ctx.verify_mode = ssl.CERT_NONE

    def request(self, url, timeout=15):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
            with urllib.request.urlopen(req, context=self.ctx, timeout=timeout) as response:
                return response.read()
        except Exception as e:
            # xbmc.log(f"Erro na requisição para {url}: {e}", level=xbmc.LOGERROR)
            return None

class HadesMaster:
    def __init__(self):
        self.net = NetUtils()
        self.user = ADDON.getSetting('username')
        self.password = ADDON.getSetting('password')

    def clean_text(self, text):
        if not text: return ""
        text = str(text).strip()
        try:
            if len(text) > 10 and re.match('^[A-Za-z0-9+/]+={0,2}$', text):
                text = base64.b64decode(text).decode('utf-8', 'ignore')
        except: pass
        return html.unescape(re.sub(r'<[^>]+?>', '', text)).strip()

    def get_srv_status(self, srv):
        url = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}"
        res = self.net.request(url, timeout=5)
        if res:
            try:
                u = json.loads(res.decode('utf-8', 'ignore')).get('user_info', {})
                return f"[COLOR lawngreen]ON[/COLOR] |[COLOR deepskyblue]{u.get('active_cons','0')}/{u.get('max_connections','0')}[/COLOR]"
            except json.JSONDecodeError as e:
                # xbmc.log(f"Erro ao decodificar JSON do status do servidor {srv.get('nome', 'desconhecido')}: {e}\nDados: {res.decode('utf-8', 'ignore')}", level=xbmc.LOGERROR)
                return "[COLOR red]ERRO[/COLOR]"
            except Exception as e:
                # xbmc.log(f"Erro inesperado ao obter status do servidor {srv.get('nome', 'desconhecido')}: {e}", level=xbmc.LOGERROR)
                return "[COLOR red]ERRO[/COLOR]"
        return "[COLOR red]OFF[/COLOR]"

    def do_login(self):
        u = xbmcgui.Dialog().input('Usuário HADES:', type=xbmcgui.INPUT_ALPHANUM)
        p = xbmcgui.Dialog().input('Senha HADES:', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if u and p:
            u_e = base64.b64encode(u.encode('utf-8')).decode('utf-8')
            p_e = base64.b64encode(p.encode('utf-8')).decode('utf-8')
            url = f"{AUTH_SITE}?action=acesso&username={urllib.parse.quote_plus(u_e)}&password={urllib.parse.quote_plus(p_e)}"
            res = self.net.request(url)
            if res and b"ativado" in res.lower():
                try:
                    ping_url = f"{AUTH_SITE}ping/ping.php"
                    self.net.request(ping_url, timeout=5)
                except: pass
                
                ADDON.setSetting('username', u)
                ADDON.setSetting('password', p)
                ADDON.setSetting('last_login', datetime.datetime.now().strftime('%d/%m/%Y %H:%M'))
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("HADES", "Acesso inválido ou expirado!")

    def router(self, paramstring):
        hades_auto_optimize()
        params = dict(urllib.parse.parse_qsl(paramstring))
        action = params.get('action')
        
        if not self.user or not self.password:
            if action == 'login_trigger': self.do_login()
            else:
                li = xbmcgui.ListItem(label="[COLOR yellow]FAZER LOGIN NO ADDON HADES[/COLOR]")
                li.setArt({'icon': IMG_TV, 'thumb': IMG_TV}); apply_fanart(li, IMG_TV)
                xbmcplugin.addDirectoryItem(ADDON_HANDLE, f"{BASE_URL}?action=login_trigger", li, False)
                xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return

        # --- INÍCIO DA CORREÇÃO PARA REMOTE_LISTS_URL ---
        data_rem = self.net.request(REMOTE_LISTS_URL)
        if not data_rem:
            xbmcgui.Dialog().ok("Erro Hades", f"Não foi possível conectar ao servidor de listas em: {REMOTE_LISTS_URL}\nVerifique sua conexão com a internet ou tente mais tarde.")
            xbmcplugin.endOfDirectory(ADDON_HANDLE) # Garante que o addon feche corretamente
            return

        try:
            decoded_data_rem = data_rem.decode('utf-8', 'ignore')
            listas = json.loads(decoded_data_rem)
        except json.JSONDecodeError as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro ao decodificar JSON da lista de servidores:\n{e}\n\nDados recebidos (início):\n{decoded_data_rem[:500]}...") # Mostra apenas o início para evitar logs gigantes
            xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return
        except Exception as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro inesperado ao processar a lista de servidores:\n{e}")
            xbmcplugin.endOfDirectory(ADDON_HANDLE)
            return
        # --- FIM DA CORREÇÃO PARA REMOTE_LISTS_URL ---
        
        if action is None: self.main_menu(listas)
        elif action == 'show_account': self.show_account_info()
        elif action == 'server_home': self.server_home(int(params.get('l_idx')), listas[int(params.get('l_idx'))])
        elif action == 'list_cats': self.list_categories(int(params.get('l_idx')), listas[int(params.get('l_idx'))], params.get('type'))
        elif action == 'list_streams':
            if params.get('adult') == '1':
                if xbmcgui.Dialog().input('Digite a Senha de Acesso:', option=xbmcgui.ALPHANUM_HIDE_INPUT) != ADULT_PIN:
                    xbmcgui.Dialog().ok("HADES", "Senha Incorreta!")
                    return
            self.list_streams(int(params.get('l_idx')), listas[int(params.get('l_idx'))], params.get('type'), params.get('cat_id'))
        elif action == 'series_episodes': self.list_episodes(int(params.get('l_idx')), listas[int(params.get('l_idx'))], params.get('id'))
        elif action == 'get_info': self.show_info_and_play(int(params.get('l_idx')), listas[int(params.get('l_idx'))], params)
        elif action == 'do_search': self.execute_search(int(params.get('l_idx')), listas[int(params.get('l_idx'))], params.get('type'))

    def main_menu(self, listas):
        li = xbmcgui.ListItem(label="[COLOR gold]INFORMAÇÕES DA CONTA[/COLOR]")
        li.setArt({'icon': IMG_CONTA, 'thumb': IMG_CONTA}); apply_fanart(li, IMG_TV)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, f"{BASE_URL}?action=show_account", li, True)
        for i, l in enumerate(listas):
            status = self.get_srv_status(l)
            li_label = f"[COLOR white]{l['nome'].upper()}[/COLOR] | [B]ADDON [COLOR pink]HA[/COLOR][COLOR yellow]DES[/COLOR][/B] | {status}"
            li = xbmcgui.ListItem(label=li_label)
            li.setArt({'icon': IMG_TV, 'thumb': IMG_TV}); apply_fanart(li, IMG_TV)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, f"{BASE_URL}?action=server_home&l_idx={i}", li, True)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    def show_account_info(self):
        u_e = base64.b64encode(self.user.encode('utf-8')).decode('utf-8')
        p_e = base64.b64encode(self.password.encode('utf-8')).decode('utf-8')
        url = f"{AUTH_SITE}?action=vencimento&username={urllib.parse.quote_plus(u_e)}&password={urllib.parse.quote_plus(p_e)}"
        res = self.net.request(url)
        
        venc = "Falha de conexão"
        if res:
            try:
                decoded_res = res.decode('utf-8', 'ignore')
                venc = decoded_res.strip()
            except Exception as e:
                # xbmc.log(f"Erro ao decodificar resposta de vencimento: {e}\nDados: {res}", level=xbmc.LOGERROR)
                venc = "Erro ao processar dados"

        last_login = ADDON.getSetting('last_login')
        vip = "Ativo" # Esta informação não é obtida dinamicamente, apenas um placeholder
        
        msg = (
            f"[COLOR gold]USUÁRIO:[/COLOR] {self.user.upper()}\n"
            f"[COLOR gold]SENHA:[/COLOR] ****\n"
            f"[COLOR gold]VIP:[/COLOR] {vip}\n"
            f"[COLOR gold]ENTRADA:[/COLOR] {last_login}\n"
            f"[COLOR gold]VENCIMENTO:[/COLOR][COLOR lawngreen]{venc}[/COLOR]"
        )
        xbmcgui.Dialog().ok("INFORMAÇÕES DA CONTA", msg)

    def server_home(self, idx, srv):
        menu = [("[COLOR pink]TV AO VIVO[/COLOR]", "live", IMG_TV), ("[COLOR orange]FILMES[/COLOR]", "vod", IMG_FILMES), ("[COLOR lawngreen]SÉRIES[/COLOR]", "series", IMG_SERIES)]
        for t, m, img in menu:
            li = xbmcgui.ListItem(label=t)
            li.setArt({'icon': img, 'thumb': img}); apply_fanart(li, img)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, f"{BASE_URL}?action=list_cats&l_idx={idx}&type={m}", li, True)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    def list_categories(self, idx, srv, stype):
        fanart_bg = IMG_TV if stype == "live" else IMG_FILMES if stype == "vod" else IMG_SERIES
        color = "pink" if stype == "live" else "orange" if stype == "vod" else "lawngreen"
        s_icon = IMG_SEARCH_TV if stype == "live" else IMG_SEARCH_FILMES if stype == "vod" else IMG_SEARCH_SERIES
        s_label = "BUSCAR TV" if stype == "live" else "BUSCAR FILMES" if stype == "vod" else "BUSCAR SÉRIES"

        li_search = xbmcgui.ListItem(label=f"[COLOR white]{s_label}[/COLOR]")
        li_search.setArt({'icon': s_icon, 'thumb': s_icon, 'fanart': fanart_bg})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, f"{BASE_URL}?action=do_search&l_idx={idx}&type={stype}", li_search, True)
        
        url_cats = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}&action=get_{'vod' if stype=='vod' else stype}_categories"
        res = self.net.request(url_cats)
        if not res:
            xbmcgui.Dialog().ok("Erro Hades", f"Não foi possível obter categorias do servidor {srv.get('nome', 'desconhecido')}.\nVerifique a conexão com este servidor.")
            return
        
        try:
            decoded_res = res.decode('utf-8', 'ignore')
            categories = json.loads(decoded_res)
        except json.JSONDecodeError as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro ao decodificar JSON de categorias do servidor {srv.get('nome', 'desconhecido')}:\n{e}\n\nDados recebidos (início):\n{decoded_res[:500]}...")
            return
        except Exception as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro inesperado ao processar categorias do servidor {srv.get('nome', 'desconhecido')}:\n{e}")
            return

        for c in categories:
            name = c['category_name']
            is_adult = any(key in name.lower() for key in ADULT_KEYS)
            u = f"{BASE_URL}?action=list_streams&l_idx={idx}&type={stype}&cat_id={c['category_id']}&adult={'1' if is_adult else '0'}"
            li = xbmcgui.ListItem(label=f"[COLOR {color}]{name}[/COLOR]")
            apply_fanart(li, fanart_bg)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, u, li, True)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    def list_streams(self, idx, srv, stype, cid):
        fanart_bg = IMG_TV if stype == "live" else IMG_FILMES if stype == "vod" else IMG_SERIES
        color = "pink" if stype == "live" else "orange" if stype == "vod" else "lawngreen"
        act = "get_live_streams" if stype == "live" else "get_vod_streams" if stype == "vod" else "get_series"
        
        url_streams = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}&action={act}&category_id={cid}"
        res = self.net.request(url_streams)
        if not res:
            xbmcgui.Dialog().ok("Erro Hades", f"Não foi possível obter streams do servidor {srv.get('nome', 'desconhecido')} para a categoria {cid}.")
            return
        
        try:
            decoded_res = res.decode('utf-8', 'ignore')
            streams = json.loads(decoded_res)
        except json.JSONDecodeError as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro ao decodificar JSON de streams do servidor {srv.get('nome', 'desconhecido')}:\n{e}\n\nDados recebidos (início):\n{decoded_res[:500]}...")
            return
        except Exception as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro inesperado ao processar streams do servidor {srv.get('nome', 'desconhecido')}:\n{e}")
            return

        for i in streams:
            name = i.get('name') or i.get('title')
            li = xbmcgui.ListItem(label=f"[COLOR {color}]{name}[/COLOR]")
            img = i.get('stream_icon') or i.get('cover')
            li.setArt({'icon': img, 'thumb': img, 'fanart': img if stype != 'live' else fanart_bg})
            u = f"{BASE_URL}?action={'series_episodes' if stype == 'series' else 'get_info'}&l_idx={idx}&type={stype}&id={i.get('stream_id') or i.get('series_id')}&name={urllib.parse.quote(name)}"
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, u, li, (stype == 'series'))
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    def list_episodes(self, idx, srv, sid):
        url_episodes = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}&action=get_series_info&series_id={sid}"
        res = self.net.request(url_episodes)
        if not res:
            xbmcgui.Dialog().ok("Erro Hades", f"Não foi possível obter informações da série {sid} do servidor {srv.get('nome', 'desconhecido')}.")
            return

        try:
            decoded_res = res.decode('utf-8', 'ignore')
            data = json.loads(decoded_res)
        except json.JSONDecodeError as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro ao decodificar JSON de informações da série {sid} do servidor {srv.get('nome', 'desconhecido')}:\n{e}\n\nDados recebidos (início):\n{decoded_res[:500]}...")
            return
        except Exception as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro inesperado ao processar informações da série {sid} do servidor {srv.get('nome', 'desconhecido')}:\n{e}")
            return

        eps = data.get('episodes', {})
        cover = data.get('info', {}).get('cover') or IMG_SERIES
        for s in sorted(eps.keys()):
            for e in eps[s]:
                t = f"T{s} E{e.get('episode_num')} - {e.get('title')}"
                u = f"{BASE_URL}?action=get_info&l_idx={idx}&type=series&id={sid}&eid={e.get('id')}&name={urllib.parse.quote(t)}"
                li = xbmcgui.ListItem(label=f"[COLOR lawngreen]{t}[/COLOR]")
                img = e.get('info', {}).get('movie_image') or cover
                li.setArt({'icon': img, 'thumb': img, 'fanart': img})
                xbmcplugin.addDirectoryItem(ADDON_HANDLE, u, li, False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    def execute_search(self, idx, srv, stype):
        q = xbmcgui.Dialog().input('O que busca?', type=xbmcgui.INPUT_ALPHANUM).lower()
        if not q: return
        color = "pink" if stype == "live" else "orange" if stype == "vod" else "lawngreen"
        fanart_bg = IMG_TV if stype == "live" else IMG_FILMES if stype == "vod" else IMG_SERIES
        act = "get_live_streams" if stype == "live" else "get_vod_streams" if stype == "vod" else "get_series"
        
        url_all_streams = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}&action={act}"
        res = self.net.request(url_all_streams)
        if not res:
            xbmcgui.Dialog().ok("Erro Hades", f"Não foi possível obter a lista completa de conteúdo para busca no servidor {srv.get('nome', 'desconhecido')}.")
            return

        try:
            decoded_res = res.decode('utf-8', 'ignore')
            all_content = json.loads(decoded_res)
        except json.JSONDecodeError as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro ao decodificar JSON para busca no servidor {srv.get('nome', 'desconhecido')}:\n{e}\n\nDados recebidos (início):\n{decoded_res[:500]}...")
            return
        except Exception as e:
            xbmcgui.Dialog().ok("Erro Hades", f"Erro inesperado ao processar dados para busca no servidor {srv.get('nome', 'desconhecido')}:\n{e}")
            return

        for i in all_content:
            name_orig = i.get('name') or i.get('title') or ""
            if q in name_orig.lower():
                li = xbmcgui.ListItem(label=f"[COLOR {color}]{name_orig}[/COLOR]")
                img = i.get('stream_icon') or i.get('cover')
                li.setArt({'icon': img, 'thumb': img, 'fanart': img if stype != 'live' else fanart_bg})
                u = f"{BASE_URL}?action={'series_episodes' if stype == 'series' else 'get_info'}&l_idx={idx}&type={stype}&id={i.get('stream_id') or i.get('series_id')}&name={urllib.parse.quote(name_orig)}"
                xbmcplugin.addDirectoryItem(ADDON_HANDLE, u, li, (stype == 'series'))
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    def show_info_and_play(self, idx, srv, p):
        stype, item_id, name = p.get('type'), p.get('id'), urllib.parse.unquote(p.get('name'))
        msg = "Carregando detalhes..."
        
        if stype == 'live':
            url_epg = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}&action=get_short_epg&stream_id={item_id}"
            d_res = self.net.request(url_epg)
            if d_res:
                try:
                    decoded_d_res = d_res.decode('utf-8', 'ignore')
                    d = json.loads(decoded_d_res)
                    if d.get('epg_listings'):
                        now = d['epg_listings'][0]
                        msg = f"[COLOR lawngreen]AGORA:[/COLOR] {self.clean_text(now.get('title'))}\n[COLOR white]{self.clean_text(now.get('description'))}[/COLOR]"
                    else:
                        msg = "Informações de EPG indisponíveis no momento."
                except json.JSONDecodeError as e:
                    # xbmc.log(f"Erro ao decodificar JSON de EPG para stream {item_id}: {e}\nDados: {decoded_d_res[:500]}...", level=xbmc.LOGERROR)
                    msg = f"Erro ao carregar informações de EPG. (Ver logs)"
                except Exception as e:
                    # xbmc.log(f"Erro inesperado ao obter EPG para stream {item_id}: {e}", level=xbmc.LOGERROR)
                    msg = f"Erro inesperado ao carregar EPG. (Ver logs)"
            else:
                msg = "Não foi possível obter informações de EPG."
        else: # vod ou series
            act_i = "get_vod_info" if stype == 'vod' else "get_series_info"
            param = "vod_id" if stype == 'vod' else "series_id"
            url_info = f"{srv['url']}/player_api.php?username={srv['user']}&password={srv['pass']}&action={act_i}&{param}={item_id}"
            d_res = self.net.request(url_info)
            if d_res:
                try:
                    decoded_d_res = d_res.decode('utf-8', 'ignore')
                    d = json.loads(decoded_d_res)
                    inf = d.get('info', {})
                    if inf:
                        msg = f"[COLOR gold]SINOPSE:[/COLOR]\n{self.clean_text(inf.get('plot'))}"
                    else:
                        msg = "Informações detalhadas não encontradas."
                except json.JSONDecodeError as e:
                    # xbmc.log(f"Erro ao decodificar JSON de info para {stype} {item_id}: {e}\nDados: {decoded_d_res[:500]}...", level=xbmc.LOGERROR)
                    msg = f"Erro ao carregar informações detalhadas. (Ver logs)"
                except Exception as e:
                    # xbmc.log(f"Erro inesperado ao obter info para {stype} {item_id}: {e}", level=xbmc.LOGERROR)
                    msg = f"Erro inesperado ao carregar informações. (Ver logs)"
            else:
                msg = "Não foi possível obter informações detalhadas."

        if xbmcgui.Dialog().yesno(name, msg or "Deseja assistir?"):
            self.play_now(srv, item_id, stype, p.get('eid', ''), name)

    def play_now(self, srv, sid, stype, eid, name):
        pipe = f"|User-Agent={urllib.parse.quote(USER_AGENT)}"
        
        # SISTEMA REPRODUÇÃO HLS (.m3u8) 
        if stype == 'live': 
            path = f"{srv['url']}/live/{srv['user']}/{srv['pass']}/{sid}.m3u8{pipe}"
            li = xbmcgui.ListItem(label=name, path=path)
            li.setProperty('IsPlayable', 'true')
            
            # FORÇAR REPRODUÇÃO PELO HLS (InputStream Adaptive nativo do Kodi)
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
        elif stype == 'vod': 
            path = f"{srv['url']}/movie/{srv['user']}/{srv['pass']}/{sid}.mp4{pipe}"
            li = xbmcgui.ListItem(label=name, path=path)
            li.setProperty('IsPlayable', 'true')
        else: # series
            path = f"{srv['url']}/series/{srv['user']}/{srv['pass']}/{eid}.mp4{pipe}"
            li = xbmcgui.ListItem(label=name, path=path)
            li.setProperty('IsPlayable', 'true')
            
        xbmc.Player().play(path, li)

if __name__ == '__main__':
    HadesMaster().router(sys.argv[2][1:])
'''

# --- SISTEMA DE AUTO-CRIPTOGRAFIA IMEDIATA ---
try:
    import os
    current_file = os.path.abspath(__file__)
    with open(current_file, 'r', encoding='utf-8') as f:
        texto = f.read()
    
    if "cmp = zlib.compress" in texto: # Verifica se já foi criptografado
        cmp = zlib.compress(_C.encode('utf-8'))
        b64 = base64.b64encode(cmp).decode('utf-8')
        novo_conteudo = f"# -*- coding: utf-8 -*-\n# Protegido por Hades\nimport zlib, base64\nexec(zlib.decompress(base64.b64decode('{b64}')).decode('utf-8'))\n"
        with open(current_file, 'w', encoding='utf-8') as f:
            f.write(novo_conteudo)
except Exception as e:
    # xbmc.log(f"Erro no sistema de auto-criptografia: {e}", level=xbmc.LOGERROR)
    pass

exec(_C)